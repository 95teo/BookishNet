﻿(function() {
    "use strict";

    angular.module("BookishNet",
        [
            // Angular modules 
            "ngRoute"

            // Custom modules 
            // 3rd Party Modules
        ]);
})();
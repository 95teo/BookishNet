﻿namespace BookishNet.DataLayer.Models
{
    public class LoginCredentialsDTO
    {
        public string Username { get; set; }
        public string Password { get; set; }
    }
}
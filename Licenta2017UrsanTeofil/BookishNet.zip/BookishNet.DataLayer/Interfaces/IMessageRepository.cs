﻿using BookishNet.DataLayer.Models;

namespace BookishNet.DataLayer.Interfaces
{
    public interface IMessageRepository : IGenericRepository<Message>
    {
    }
}
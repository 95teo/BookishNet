﻿using BookishNet.DataLayer.Models;

namespace BookishNet.DataLayer.Interfaces
{
    public interface IGenreRepository : IGenericRepository<Genre>
    {
    }
}